<?php

	$about = array(
		'name' => 'Nederlands',
		'author' => array(
			'name' => 'Carsten de Vries',
			'email' => 'carsten@vrieswerk.nl',
			'website' => 'http://www.vrieswerk.nl'
		),
		'release-date' => '2009-11-09'
	);

	
	/*
	 * EXTENSION: Debug Devkit
	 * Localisation strings
	 */

	$dictionary = array(
	
		'Debug' => 
		'Foutenoplossing',

		'Params' => 
		'Parameters',

		'XML' => 
		'XML',

		'Result' => 
		'Resultaat'
		
	);
	