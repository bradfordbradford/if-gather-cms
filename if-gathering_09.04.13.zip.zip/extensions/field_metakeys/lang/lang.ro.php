<?php

	$about = array(
		'name' => 'Română',
		'author' => array(
			'name' => 'Vlad Ghita',
			'email' => 'vlad_micutul@yahoo.com',
			'website' => ''
		),
		'release-date' => '2010-11-12',
	);

	/**
	 * Field: Meta Keys
	 */
	$dictionary = array(

		'An error occurred while installing %s. %s' => 
		'A intervenit o eroare la instalarea %s. %s',

		'An error occurred while uninstalling %s. %s' => 
		'A intervenit o eroare la dezinstalarea %s. %s',

		'Meta Keys' => 
		'Meta Atribute',

		'Default Keys' => 
		'Atribute Implicite',
	
		'Key' => 
		'Atribut',
	
		'Value' => 
		'Valoare',

	);
