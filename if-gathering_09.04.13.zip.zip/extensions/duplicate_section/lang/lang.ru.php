<?php

	$about = array(
		'name' => 'Русский',
		'author' => array(
			'name' => 'Александр Бирюков',
			'email' => 'info@alexbirukov.ru',
			'website' => 'http://alexbirukov.ru'
		),
		'release-date' => '2012-10-19'
	);

	/**
	 * Duplicate Section
	 */
	$dictionary = array(

		'Clone' => 
		'Дублировать',

		'Duplicate this section' => 
		'Дублировать данный раздел',

	);
