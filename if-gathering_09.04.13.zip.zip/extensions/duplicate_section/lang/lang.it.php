<?php

  $about = array(
		'name' => 'Italian',
		'author' => array(
			'name' => 'Davide Grobberio',
			'email' => 'davide@zaniniadv.it',
			'website' => 'http://www.zaniniadv.it'
		),
		'release-date' => '2013-03-30',
	);


	/**
	 * Save and return
	 */
	$dictionary = array(

		'Easily duplicate/clone your section parameters and fields' =>
		'Duplica facilmente parametri e campi della tua sezione',
		
		'Clone' =>
		'Duplica',
		
		'Duplicate this section' =>
		'Duplica questa sezione'
	);
