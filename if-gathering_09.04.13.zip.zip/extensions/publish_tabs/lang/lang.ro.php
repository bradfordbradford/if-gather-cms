<?php

	$about = array(
		'name' => 'Română',
		'author' => array(
			'name' => 'Vlad Ghita',
			'email' => 'vlad_micutul@yahoo.ro',
		),
		'release-date' => '2011-02-08'
	);

	/**
	 * Publish Tabs
	 */
	$dictionary = array(
		'Untitled Tab' =>
		'Tab neintitulat',

		'Publish Tab' =>
		false,

	);
