(function($) {

	$(document).on('ready.publishshortcuts', function() {
		$('.publishshortcuts').symphonyDuplicator({
			collapsible: true
		});
	});

})(window.jQuery);
