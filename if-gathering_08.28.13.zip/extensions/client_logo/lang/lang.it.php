<?php

	$about = array(
		'name' => 'Italian',
		'author' => array(
			'name' => 'Andrea Moretti',
			'email' => 'mail@bbox.it',
			'website' => 'http://www.bbox.it'
		),
		'release-date' => '2011-01-08'
	);
	
	
	/*
	 * EXTENSION: Client Logo
	 * Localisation strings
	 */

	$dictionary = array(

		'Client logo path (relative to workspace)' =>
		'Logo del cliente (path relativo rispetto al workspace)'

	);