<?php

	$about = array(
		'name' => 'Русский',
		'author' => array(
			'name' => 'Александр Бирюков',
			'email' => 'info@alexbirukov.ru',
			'website' => 'http://alexbirukov.ru'
		),
		'release-date' => '2012-12-11'
	);

	/**
	 * HTML5 Doctype
	 */
	$dictionary = array(

		'Exclude Types' => 
		'Исключить типы',

	);
