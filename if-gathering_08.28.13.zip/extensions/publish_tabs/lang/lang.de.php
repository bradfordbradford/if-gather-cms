<?php

	$about = array(
		'name' => 'Deutsch',
		'author' => array(
			'name' => 'Nils Hörrmann',
			'email' => 'post@nilshoerrmann.de',
			'website' => 'http://nilshoerrmann.de'
		),
		'release-date' => '2011-02-15'
	);

	/**
	 * Publish Tabs
	 */
	$dictionary = array(

		'Untitled Tab' => 
		'Ohne Titel',

		'Publish Tab' => 
		'Reiter',

	);
