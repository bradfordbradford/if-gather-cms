<?php

  $about = array(
		'name' => 'Italian',
		'author' => array(
			'name' => 'Davide Grobberio',
			'email' => 'davide@zaniniadv.it',
			'website' => 'http://www.zaniniadv.it'
		),
		'release-date' => '2013-01-27'
	);
	
	
	/*
	 * EXTENSION: Debug Devkit
	 * Localisation strings
	 */

	$dictionary = array(

		'Debug' => 
		'Debug',

		'Params' => 
		'Parametri',

		'XML' => 
		'XML',

		'Result' => 
		'Risultati'	

	);
	
