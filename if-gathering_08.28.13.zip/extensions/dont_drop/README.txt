Don't Drop
==========

Hides single Section Navigation Group dropdown-menus

Version: 1.4
Author: Nils Werner (nils.werner@gmail.com)
Build Date: 2012-06-11
Requirements: Symphony 2.3


Installation
------------

1. Upload the 'dont_drop' folder in this archive to your Symphony 'extensions' folder.

2. Enable it by selecting the "Don't Drop!" entry, choose Enable from the with-selected menu, then click Apply.
