<?php

	$about = array(
		'name' => 'Français',
		'author' => array(
			'name' => 'Solutions Nitriques',
			'email' => 'nico (at) nitriques.com',
			'website' => 'http://www.nitriques.com/'
		),
		'release-date' => '2011-07-08',
	);


	/**
	 * Save and return
	 */
	$dictionary = array(

		'Easily duplicate/clone your section parameters and fields' =>
		'Duplique/clone facilement une section avec ses paramètres et ses champs',
		
		
		'Clone' =>
		'Cloner',
		
		'Duplicate this section' =>
		'Dupliquer cette section'
	);
