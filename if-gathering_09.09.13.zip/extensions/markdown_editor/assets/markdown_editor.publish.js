jQuery(document).ready(function($) {
	$('textarea[class*=markdown]').markdownEditor();
});
