<?php

	$about = array(
		'name' => 'Română',
		'author' => array(
			'name' => 'Vlad Ghita',
			'email' => 'vlad_micutul@yahoo.com',
			'website' => ''
		),
		'release-date' => '2011-02-09'
	);

	/**
	 * Order Entries
	 */
	$dictionary = array(
	
		'drag to reorder' =>
		'trage pentru rearanjare',

		'Entry order saved.' =>
		'Ordinea înregistrărilor salvată.',

		'Entry Order' =>
		false,

		'%s Disable sorting of other columns when enabled' =>
		'%s Când este activată, dezactivează sortarea prin celelalte coloane ',

		'%s Hide this field on publish page' =>
		'%s Ascunde acest câmp pe pagina de publicare',

	);
