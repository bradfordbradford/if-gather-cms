# Duplicate Sections #

Version: 1.2 

## Easily duplicate/clone your section parameters and fields ##

### SPECS ###

- Adds a 'Clone' button on the bottom-left of the edit page of a section

### REQUIREMENTS ###

- Symphony CMS version 2.3 and up (as of the day of the last release of this extension)

For user with symphony CMS version 2.2.x, use tag V1.1

### INSTALLATION ###

- Unzip the duplicate_section.zip file
- (re)Name the folder ***duplicate_section***
- Put into the extension directory
- Enable/install just like any other extension

*Voila !*

http://www.nitriques.com/open-source/
