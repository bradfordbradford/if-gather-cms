<?php

	$about = array(
		'name' => 'Italiano',
		'author' => array(
			'name' => 'Simone Economo',
			'email' => 'my.ekoes@gmail.com',
			'website' => 'http://lineheight.net',
		),
	);
	
	
	/*
	 * EXTENSION: Publish Tabs
	 * Localisation strings
	 */

	$dictionary = array(

		'Untitled Tab' => 
		'Scheda senza titolo',

		'Publish Tab' =>
		'Scheda'

	);