<?php

	$about = array(
		'name' => 'Română',
		'author' => array(
			'name' => 'Vlad Ghita',
			'email' => 'vlad_micutul@yahoo.com',
			'website' => ''
		),
		'release-date' => '2011-02-09'
	);

	/**
	 * Field: HTML Panel
	 */
	$dictionary = array(

		'HTML Panel' =>
		'Panou HTML',
		
		'URL Expression' =>
		'Expresie URL',
	
	);
