<?php

	$about = array(
		'name' => 'Romana',
		'author' => array(
			'name' => 'Vlad Ghita',
			'email' => 'vlad.ghita@xandergroup.ro',
			'website' => 'http://www.xanderadvertising.com'
		),
		'release-date' => '2012-05-18'
	);

	$dictionary = array(

		'There is %d entry' =>
		'Exista o inregistrare',

		'There are %d entries' => 
		'Exista %d inregistrari',

		' out of a maximum of ' => 
		' dintr-un maxim de ',

		'You can\'t create more entries.' => 
		'Nu puteti crea alte inregistrari.',

		'You can create %d more' => 
		'Puteti crea inca %d',

		'entry' => 
		'inregistrare',

		'entries' => 
		'inregistrari',

		'Maximum entries' => 
		'Numar maxim de inregistrari',

		'Limit the maximum number of entries to this positive integer value. Let 0 or empty for unlimited.' => 
		'Limiteaza numarul maxim de inregistrari la acest numar natural. Lasati 0 sau gol pentru nelimitat.',

	);
