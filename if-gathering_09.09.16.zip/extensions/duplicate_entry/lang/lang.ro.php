<?php

	$about = array(
		'name' => 'Română',
		'author' => array(
			'name' => 'Vlad Ghita',
			'email' => 'vlad_micutul@yahoo.com',
			'website' => ''
		),
		'release-date' => '2010-11-12',
	);

	/**
	 * Duplicate Entry
	 */
	$dictionary = array(
	
		'Save as New' => 
		'Salvează ca Nou',

	);
