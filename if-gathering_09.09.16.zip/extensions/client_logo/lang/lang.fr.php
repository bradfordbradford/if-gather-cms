<?php

	$about = array(
		'name' => 'Français',
		'author' => array(
			'name' => 'Deux Huit Huit',
			'email' => 'open-source (at) deuxhuithuit (dot) com',
			'website' => 'http://www.deuxhuithuit.com'
		),
		'release-date' => '2012-07-13'
	);
	
	
	/*
	 * EXTENSION: Client Logo
	 * Localisation strings
	 */

	$dictionary = array(

		'Client logo path (relative to workspace)' =>
		'Chemin d\accès du logo (chemin relatif au dossier workspace)'

	);
	
	