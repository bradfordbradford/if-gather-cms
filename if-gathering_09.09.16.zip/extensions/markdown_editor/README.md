# Markdown Editor

A Markdown Editor for Symphony.

## Installation

1. Upload the 'markdown_editor' folder in this archive to your Symphony 'extensions' folder.
2. Enable it by selecting the "Markdown Editor", choose Enable from the with-selected menu, then click Apply.

## Usage

This extension automatically adds a markdown editor to every markdown textarea field on every entry page.

## Credits

This a port of the Markdown editor from the GitHub Gollum project <https://github.com/github/gollum> and inspired by <https://github.com/JFrolich/simple-markdown-editor>.