# Field: Repeating Date

A field that generates, stores and filters repeating dates.

## Installation

1. Upload the 'repeating_date_field' folder in this archive to your Symphony 'extensions' folder.
2. Enable it by selecting the "Field: Repeating Date", choose Enable from the with-selected menu, then click Apply.
3. You can now add the "Repeating Date" field to your sections.