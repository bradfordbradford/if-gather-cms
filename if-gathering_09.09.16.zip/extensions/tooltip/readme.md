This extension adds tooltips to your fields.

- When logged in as a developer, you can edit the tooltips for each field.
- When logged in as an author, you can only view the tooltips.