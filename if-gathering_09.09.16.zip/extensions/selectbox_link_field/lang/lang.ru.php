<?php

	$about = array(
		'name' => 'Русский',
		'author' => array(
			'name' => 'Александр Бирюков',
			'email' => 'info@alexbirukov.ru',
			'website' => 'http://alexbirukov.ru'
		),
		'release-date' => '2012-12-11'
	);

	/**
	 * Select Box Link Field
	 */
	$dictionary = array(

		'Allow selection of multiple options' => 
		'Разрешить выбор нескольких опций.',

		'Select Box Link' => 
		'Ссылка на запись',

		'Limit to the %s most recent entries' => 
		'Ограничение на %s последних записей.',

		'None' => 
		'Нет',

		'Options' => 
		'Опции',

		'Values' => 
		'Значения',

		'Limit to %s entries' => 
		'Лимит записей %s',

	);
