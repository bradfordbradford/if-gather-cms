<?php

	$about = array(
		'name' => 'Français',
		'author' => array(
			'name' => 'Deux Huit Huit',
			'email' => 'open-source@deuxhuithuit.com',
			'website' => 'http://www.deuxhuithuit.com'
		),
		'release-date' => '2012-10-09'
	);

	/**
	 * Unpublished Filter
	 */
	$dictionary = array(

		'published' => 
		'publié'

	);
