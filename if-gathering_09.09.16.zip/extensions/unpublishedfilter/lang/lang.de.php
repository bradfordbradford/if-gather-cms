<?php

	$about = array(
		'name' => 'Deutsch',
		'author' => array(
			'name' => 'Nils Hörrmann',
			'email' => 'post@nilshoerrmann.de',
			'website' => 'http://nilshoerrmann.de'
		),
		'release-date' => '2011-02-01'
	);

	/**
	 * Unpublished Filter
	 */
	$dictionary = array(

		'published' => 
		'veröffentlicht'

	);
