<?php

	$about = array(
		'name' => 'Русский',
		'author' => array(
			'name' => 'Александр Бирюков',
			'email' => 'info@alexbirukov.ru',
			'website' => 'http://alexbirukov.ru'
		),
		'release-date' => '2012-06-05'
	);

	/**
	 * Debug Devkit
	 */
	$dictionary = array(

		'Params' => 
		'Параметры',

		'Result' => 
		'Результат',

		'XML' => 
		'XML',


		'Debug' => 
		'Отладка',

		'Failed to create cache folder. Please check "%s" is writable.' => 
		'Ошибка создания каталога кэша. Проверьте "%s" на право записи.',

		'Cache folder is not writable. Please check permissions on "%s".' => 
		'Нет прав на запись в каталоге кэша. Пожалуйста проверьте права "%s".',

		'Plain XML' => 
		'Простой XML',

	);
